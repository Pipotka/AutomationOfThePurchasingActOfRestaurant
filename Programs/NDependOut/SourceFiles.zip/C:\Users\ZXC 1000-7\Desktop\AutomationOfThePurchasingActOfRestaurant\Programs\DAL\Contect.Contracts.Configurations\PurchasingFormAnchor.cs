﻿namespace Company.AutomationOfThePurchasingActOfRestaurant.Context.Contracts.Configurations;

/// <summary>
/// Якорный класс для регистрации конфигураций
/// </summary>
public abstract class PurchasingFormAnchor
{

}
