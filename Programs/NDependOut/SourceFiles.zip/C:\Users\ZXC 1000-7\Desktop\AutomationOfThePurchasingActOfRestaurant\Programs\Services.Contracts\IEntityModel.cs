﻿namespace Company.AutomationOfThePurchasingActOfRestaurant.Services.Contracts;

/// <summary>
/// Интерфейс модели
/// </summary>
public interface IEntityModel
{
    /// <summary>
    /// Id
    /// </summary>
    public Guid Id { get; set; }
}
